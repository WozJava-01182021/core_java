package com.rukshanu.handson8;

public interface Reptile extends Animal{
	public String crawl();
}
