package com.rukshanu.handson8;

public interface Animal {
	public String eat();
}
