package com.rukshanu.handson8;

public interface Mammal extends Animal {
	public String speak();
	public String run();
	
}
