SELECT rental_id, payment_date FROM payment WHERE amount > .99;
SELECT staff_id, customer_id FROM payment WHERE amount > .99;